<template>
  <footer>
    <div class="container-fluid">
      <div class="row">
        <div class="footer-content">
          <div class="logo-home"></div>
          <div class="footer-text">
            <div class="social-links">
              <span class="social twitter"><a href="https://twitter.com/pineviewlabs" target="_blank">Twitter</a></span>
              <span class="social github"><a href="https://github.com/pineviewlabs" target="_blank">Github</a></span>
            </div>

            <p>© 2022 Middlemarch. All Right Reserved.</p>
          </div>
        </div>
      </div>
    </div>
  </footer>
</template>

<style scoped>
footer {
  min-height: 300px;
  text-align: center;
  background-color: #111222;
  padding-top: 120px;
  font-size: 16px;
  font-weight: 200;
  color: #969696;
  padding-right: 20px;
  padding-bottom: 20px;
}
</style>

<script>
export default {
  data() {
    return {

    };
  },
  methods: {

  }
};
</script>