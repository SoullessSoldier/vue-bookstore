import SignInComponent from './sign-in/SignIn.vue'

export {
  SignInComponent
}